c
c   Flags for parallel execution
c   to be cleared on each new execution of parpack
c   
c

      logical    apps_first, aitr_first
      common/pcntxt/  apps_first, aitr_first