/*
 * Copyright (c) 2013      The University of Tennessee and The University
 *                         of Tennessee Research Foundation.  All rights
 *                         reserved.
 */

#include "parsec/parsec_config.h"
#include "parsec/class/fifo.h"

OBJ_CLASS_INSTANCE(parsec_fifo_t, parsec_list_t,
                   NULL, NULL);
