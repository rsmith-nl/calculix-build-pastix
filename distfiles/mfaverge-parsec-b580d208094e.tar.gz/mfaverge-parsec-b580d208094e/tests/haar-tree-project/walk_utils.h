#ifndef _walk_utils_h
#define _walk_utils_h

#include "tree_dist.h"

typedef void (*walk_fn_t)(tree_dist_t *, node_t *, int , int, void *);

#endif

