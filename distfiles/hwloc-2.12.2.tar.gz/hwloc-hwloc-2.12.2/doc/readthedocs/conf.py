import subprocess, os

project = 'hwloc'
