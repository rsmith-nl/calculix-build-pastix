**The hwloc documentation starts** `here <doxygen/html/>`__.
